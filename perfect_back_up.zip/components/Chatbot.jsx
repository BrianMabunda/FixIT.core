import React, { useState } from 'react';
import { LucideSend, LucideMessageSquare, LucideZap } from 'lucide-react';

const Chatbot = ({ onStart, isLightMode }) => {
  const [clue, setClue] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (clue.trim()) {
      onStart(clue);
    }
  };

  return (
    <div className={`flex-1 flex flex-col items-center justify-center p-8 transition-all duration-700`}>
      <div className={`w-full max-w-2xl glass-panel border p-12 rounded-[3rem] relative overflow-hidden iris-protection ${
        isLightMode ? 'bg-white/60 border-black/10 shadow-2xl' : 'bg-[#141619]/60 border-white/10 shadow-2xl'
      }`}>
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-50" />
        
        <div className="flex flex-col items-center text-center mb-10">
          <div className={`p-4 rounded-2xl mb-6 ${isLightMode ? 'bg-cyan-100 text-cyan-600' : 'bg-cyan-500/10 text-cyan-400'}`}>
            <LucideMessageSquare size={32} />
          </div>
          <h1 className="text-4xl font-light tracking-tight mb-4">
            How can the <span className="text-cyan-500 font-semibold">Agent</span> assist you?
          </h1>
          <p className="text-sm font-mono opacity-50 tracking-widest uppercase">
            Initialize diagnostic via natural language input
          </p>
        </div>

        <form onSubmit={handleSubmit} className="relative group">
          <textarea
            value={clue}
            onChange={(e) => setClue(e.target.value)}
            placeholder="Describe the issue (e.g., 'My internet is slow and the router light is red')..."
            className={`w-full h-40 p-6 rounded-3xl border-2 bg-transparent outline-none transition-all resize-none text-lg font-light leading-relaxed ${
              isLightMode 
                ? 'border-black/5 focus:border-cyan-400 text-slate-800 placeholder:text-slate-400' 
                : 'border-white/5 focus:border-cyan-400 text-slate-100 placeholder:text-white/20'
            }`}
          />
          
          <button
            type="submit"
            disabled={!clue.trim()}
            className={`absolute bottom-4 right-4 flex items-center gap-2 px-6 py-3 rounded-2xl font-bold text-xs tracking-widest uppercase transition-all ${
              clue.trim() 
                ? 'bg-cyan-500 text-white shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:scale-105' 
                : 'bg-slate-500/20 text-slate-500 cursor-not-allowed'
            }`}
          >
            Initiate Protocol <LucideSend size={14} />
          </button>
        </form>

        <div className="mt-8 grid grid-cols-2 gap-4">
          <div className={`flex items-center gap-3 p-4 rounded-2xl border ${isLightMode ? 'bg-black/5 border-black/5' : 'bg-white/5 border-white/5'}`}>
            <LucideZap size={16} className="text-cyan-400" />
            <span className="text-[10px] font-mono opacity-60 tracking-wider uppercase">Neural Processing Active</span>
          </div>
          <div className={`flex items-center gap-3 p-4 rounded-2xl border ${isLightMode ? 'bg-black/5 border-black/5' : 'bg-white/5 border-white/5'}`}>
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-[10px] font-mono opacity-60 tracking-wider uppercase">Link Synchronized</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;