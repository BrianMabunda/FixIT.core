import React, { useState, useEffect } from 'react';
import { LucideRotateCcw, LucideLoader2 } from 'lucide-react';

/** * Modular Imports */
import Sidebar from '../components/Sidebar';
import DiagnosticCard from '../components/DiagnosticCard';
import Chatbot from '../components/Chatbot';
// import Chatbot from '../components/Chatbot';
import '../Styles/GlobalStyles.css';

const API_BASE_URL = "http://localhost:8000";

export default function App() {
  const [history, setHistory] = useState([]);
  const [isInitialized, setIsInitialized] = useState(false);
  const [currentState, setCurrentState] = useState({
    message: "Initializing Neural Link...",
    options: [],
    confidence: 0,
    stage: "System"
  });
  const [isLightMode, setIsLightMode] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  /**
   * Initialize Session with User Clue
   * This sends the user's natural language description to the Agent via FastAPI
   */
  const handleChatbot = async (clue) => {
    setIsLoading(true);
    setIsAnimating(true);
    try {
      // 1. Reset backend state
      await fetch(`${API_BASE_URL}/diagnostic/reset`);
      
      // 2. Send the first "clue" to the Agent
      const response = await fetch(`${API_BASE_URL}/diagnostic/next`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_choice: clue })
      });
      
      if (!response.ok) throw new Error("Backend connection failed");

      const data = await response.json();
      
      setCurrentState({
        ...data,
        stage: data.current_step 
      });
      
      // Transition to main diagnostic UI
      setIsInitialized(true);
    } catch (error) {
      console.error("Failed to connect to backend:", error);
      // Fallback for demo purposes if API is offline
      setCurrentState({
        message: "Neural link offline. Ensure FastAPI is running on port 8000.",
        options: ["Start Over"],
        confidence: 0,
        stage: "System"
      });
      setIsInitialized(true); 
    } finally {
      setIsLoading(false);
      setIsAnimating(false);
    }
  };

  /**
   * Reset the whole experience back to the Input Screen
   */
  const resetSession = () => {
    setIsInitialized(false);
    setHistory([]);
    setCurrentState({
      message: "Initializing Neural Link...",
      options: [],
      confidence: 0,
      stage: "System"
    });
  };

  const toggleTheme = () => {
    setIsAnimating(true);
    setIsLightMode(!isLightMode);
    setTimeout(() => setIsAnimating(false), 800);
  };

  /**
   * Standard Step Navigation
   */
  const handleAction = async (choice) => {
    if (choice === "Return to Overview" || choice === "Start Over") {
      resetSession();
      return;
    }

    setIsLoading(true);
    setIsAnimating(true);

    try {
      const response = await fetch(`${API_BASE_URL}/diagnostic/next`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_choice: choice })
      });

      const data = await response.json();
      
      setHistory(prev => [...prev, currentState]);
      setCurrentState({
        ...data,
        stage: data.current_step
      });
    } catch (error) {
      console.error("API Error:", error);
    } finally {
      setTimeout(() => {
        setIsAnimating(false);
        setIsLoading(false);
      }, 500);
    }
  };

  const rewind = async () => {
    if (history.length === 0) return;
    setIsLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/diagnostic/rewind`, { method: 'POST' });
      if (response.ok) {
        const last = history[history.length - 1];
        setHistory(prev => prev.slice(0, -1));
        setCurrentState(last);
      }
    } catch (error) {
      console.error("Rewind failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`min-h-screen font-sans overflow-hidden transition-colors duration-1000 ${
      isLightMode ? 'bg-[#f4f7f9] text-slate-800' : 'bg-[#050506] text-slate-100'
    }`}>
      
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none transition-opacity duration-1000" style={{ opacity: isLightMode ? 0.3 : 0.6 }}>
        <div className="absolute top-[-10%] left-[-10%] w-[60vw] h-[60vw] rounded-full blur-[120px] bg-blue-600/10" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full blur-[100px] bg-cyan-400/10" />
      </div>

      <div className="relative z-10 grid grid-cols-[320px_1fr] gap-8 p-8 h-screen max-w-[1800px] mx-auto overflow-hidden">
        <Sidebar 
          activeStage={currentState.stage} 
          isLightMode={isLightMode} 
          onToggleTheme={toggleTheme} 
        />

        <main className="flex flex-col gap-8 h-full overflow-hidden">
          <div className="flex-1 relative">
            {/* Global Loader Overlay */}
            {isLoading && (
              <div className="absolute inset-0 z-50 flex items-center justify-center bg-transparent backdrop-blur-[2px] rounded-[32px]">
                <LucideLoader2 className="animate-spin text-cyan-500" size={48} />
              </div>
            )}
            
            {/* Conditional Rendering: Clue Input vs. Diagnostic Flow */}
            {!isInitialized ? (
              <Chatbot 
                onStart={handleChatbot} 
                isLightMode={isLightMode} 
              />
            ) : (
              <DiagnosticCard 
                state={currentState} 
                isLightMode={isLightMode} 
                isAnimating={isAnimating}
                onChoice={handleAction}
              />
            )}
          </div>

          <footer className="flex justify-between items-center px-10 py-4 font-mono text-[10px] tracking-[0.2em] opacity-30">
            <button 
              onClick={rewind}
              disabled={history.length === 0 || isLoading || !isInitialized}
              className={`flex items-center gap-3 px-6 py-3 rounded-2xl border transition-all ${
                history.length === 0 || isLoading || !isInitialized 
                  ? 'opacity-20 cursor-not-allowed' 
                  : 'opacity-100 hover:text-cyan-500 hover:border-cyan-500'
              }`}
            >
              <LucideRotateCcw size={14} className={isLoading ? 'animate-spin' : ''} /> REWIND_FLOW
            </button>
            
            <div className="flex gap-10">
              <span className="hidden lg:inline uppercase">
                Agent Status: {isInitialized ? 'Active' : 'Awaiting Clue'}
              </span>
              <span>NODE: CORE_AXIS_01</span>
              <span className="text-cyan-500 font-bold">LINK: STABLE</span>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}