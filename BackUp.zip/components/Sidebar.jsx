import React from 'react';
import { LucideMonitor, LucidePower, LucideCable, LucideSettings, LucideMessageCircle } from 'lucide-react';
import '../Styles/SideBarStyles.css';

const Sidebar = ({ activeStage, isLight, onToggleTheme, currentView, onViewChange }) => {
  const isLightMode = isLight;

  const navItems = [
    { id: 'initial', label: 'OVERVIEW', icon: LucideMonitor, view: 'diagnostic' },
    { id: 'Power', label: 'POWER MODULE', icon: LucidePower, view: 'diagnostic' },
    { id: 'Cables', label: 'CONNECTIVITY', icon: LucideCable, view: 'diagnostic' },
    { id: 'Configuration', label: 'SYSTEM CONFIG', icon: LucideSettings, view: 'diagnostic' }
  ];

  return (
    <aside className={`sidebar-container glass-panel border theme-transition ${
      isLightMode 
        ? 'is-light bg-white/40 border-black/10 shadow-xl text-slate-900' 
        : 'is-dark bg-black/40 border-white/10 shadow-2xl text-white'
    }`}>
      <div className="mb-12">
        <h2 className="text-2xl font-bold tracking-tighter">
          Fix<span className="text-cyan-500 animate-pulse">IT</span>.core
        </h2>
        <p className={`text-[10px] font-mono mt-1 tracking-widest uppercase ${
          isLightMode ? 'opacity-50 text-slate-600' : 'opacity-60 text-cyan-400'
        }`}>
          Neural Interface v2.4
        </p>
      </div>

      <nav className="space-y-2 flex-1">
        {navItems.map((item) => {
          const isActive = activeStage === item.id && currentView === 'diagnostic';
          return (
            <div 
              key={item.id}
              onClick={() => onViewChange('diagnostic', item.id)}
              className={`nav-item-glass flex items-center gap-3 p-4 rounded-xl font-bold cursor-pointer transition-all duration-300 ${
                isActive 
                  ? 'bg-cyan-500/20 text-cyan-500 border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.2)]' 
                  : isLightMode 
                    ? 'text-slate-500 hover:bg-black/5' 
                    : 'text-slate-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <item.icon size={18} strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[11px] tracking-widest font-bold">
                {item.label}
              </span>
            </div>
          );
        })}

        <div className="my-6 border-t border-white/10 opacity-20" />

        {/* New Chatbot Navigation Button */}
        <div 
          onClick={() => onViewChange('chatbot')}
          className={`nav-item-glass flex items-center gap-3 p-4 rounded-xl font-bold cursor-pointer transition-all duration-300 ${
            currentView === 'chatbot'
              ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30 shadow-[0_0_15px_rgba(168,85,247,0.2)]'
              : isLightMode
                ? 'text-slate-500 hover:bg-black/5'
                : 'text-slate-400 hover:bg-white/5 hover:text-white'
          }`}
        >
          <LucideMessageCircle size={18} strokeWidth={currentView === 'chatbot' ? 2.5 : 2} />
          <span className="text-[11px] tracking-widest font-bold">NEURAL_CHAT</span>
        </div>
      </nav>

      {/* Theme Toggle Section */}
      <div 
        onClick={onToggleTheme} 
        className={`mt-4 theme-toggle-switch group transition-colors duration-300 flex items-center justify-between p-4 rounded-2xl cursor-pointer border ${
          isLightMode ? 'bg-black/5 border-black/10' : 'bg-white/5 border-white/10 hover:border-cyan-500/50'
        }`}
      >
        <span className={`font-mono text-[9px] tracking-wider transition-opacity ${
          isLightMode ? 'opacity-70 text-slate-900' : 'opacity-80 text-white'
        } group-hover:opacity-100`}>
          {isLightMode ? 'LIGHT_LINK' : 'DARK_VOID'}
        </span>
        <div className={`w-10 h-5 rounded-full relative flex items-center px-1 border transition-all duration-500 ${
          isLightMode ? 'bg-cyan-500 border-cyan-400' : 'bg-slate-700/50 border-white/10'
        }`}>
          <div className={`w-3 h-3 bg-white rounded-full transition-transform duration-500 shadow-sm transform ${
            isLightMode ? 'translate-x-5' : 'translate-x-0'
          }`} />
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;